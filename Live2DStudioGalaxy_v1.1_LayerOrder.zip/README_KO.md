# Live2D Studio Galaxy Edition v1.1 (레이어 순서 편집 프로토타입)

## v1.1 변경 사항
- v1.0 통합 프로토타입 기반
- 선택한 레이어를 계층에서 위/아래로 이동하는 기능 추가
- 레이어 순서 변경은 캔버스 렌더링 순서 및 프로젝트 저장 순서에 반영
- 앱 버전 및 GitHub Actions 산출물 이름을 v1.1로 갱신

## 기존 기능
- 이미지 여러 장 가져오기
- OpenRaster(.ora) 레이어 가져오기
- 레이어 표시/숨기기, 이동, 확대/축소, 회전, 투명도 조절
- `.galaxy.zip` 프로젝트 저장/불러오기
- 기초 회전 리깅 및 사인파 기반 흔들림 미리보기
- 타임라인 키프레임과 선형 보간

## 제한 사항
이것은 기초 2D 레이어 편집 프로토타입이며 정식 Live2D Cubism Editor와 동등하지 않습니다.
- PSD 직접 가져오기 미지원 (OpenRaster .ora 지원)
- 정식 Cubism ArtMesh/디포머/물리 엔진과 호환되지 않음
- Cubism `.cmo3`, `.moc3`, Motion3의 완전한 편집 및 내보내기 미지원
- 키프레임 구조는 현재 선택 레이어를 중심으로 한 기초 구현이며 다중 트랙 애니메이션이 아님
- 메쉬 편집 및 모든 리깅/물리 상태의 완전한 프로젝트 저장은 아직 미지원
- 이 소스는 현재 환경에서 Android SDK 빌드와 실기기 테스트를 완료하지 않았음

## 태블릿에서 APK 빌드
1. ZIP을 내려받고 압축을 풉니다.
2. 압축 안의 프로젝트 파일/폴더 전체를 GitHub 저장소 루트에 업로드합니다. ZIP 파일 자체를 저장소에 올리는 것만으로는 빌드되지 않습니다.
3. GitHub 저장소의 Actions 탭으로 이동합니다.
4. `Build Live2D Studio Galaxy APK` 워크플로를 선택하고 `Run workflow`를 누릅니다.
5. 작업이 성공하면 Artifacts에서 `Live2DStudioGalaxy-v1.1-debug-apk`를 내려받습니다.
6. 내려받은 아티팩트 ZIP 안의 `app-debug.apk`를 설치합니다.

## 빌드 구성
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compileSdk 35 / minSdk 26
