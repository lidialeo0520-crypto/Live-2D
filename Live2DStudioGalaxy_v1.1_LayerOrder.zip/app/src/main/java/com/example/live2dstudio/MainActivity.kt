package com.example.live2dstudio

import android.os.Bundle
import android.graphics.BitmapFactory
import android.net.Uri
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import org.xmlpull.v1.XmlPullParser
import android.util.Xml
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlinx.coroutines.delay

data class TransformKey(val x: Float, val y: Float, val scale: Float, val rotation: Float, val opacity: Float)

data class ArtLayer(
    val id: Long,
    val name: String,
    val bitmap: ImageBitmap,
    val x: Float = 0f,
    val y: Float = 0f,
    val scale: Float = 1f,
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    val visible: Boolean = true
)

private val Bg = Color(0xFF171922)
private val Panel = Color(0xFF222631)
private val Panel2 = Color(0xFF292F3B)
private val Accent = Color(0xFF438BFF)
private val Muted = Color(0xFF9BA5B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.statusBarColor = android.graphics.Color.rgb(23, 25, 34)
        window.navigationBarColor = android.graphics.Color.rgb(23, 25, 34)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) { StudioScreen() } }
    }
}

@Composable
private fun StudioScreen() {
    var selectedTop by remember { mutableStateOf("모델링") }
    var bottomTab by remember { mutableStateOf("파라미터") }
    var zoom by remember { mutableFloatStateOf(1f) }
    var eyeOpen by remember { mutableFloatStateOf(0.65f) }
    var mouth by remember { mutableFloatStateOf(0.25f) }
    var currentFrame by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var keyframes by remember { mutableStateOf<Map<Int, TransformKey>>(emptyMap()) }
    var layers by remember { mutableStateOf(listOf<ArtLayer>()) }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var rigAmount by remember { mutableFloatStateOf(0f) }
    var rigEnabled by remember { mutableStateOf(false) }
    var physicsEnabled by remember { mutableStateOf(false) }
    var physicsAmplitude by remember { mutableFloatStateOf(12f) }
    var physicsSpeed by remember { mutableFloatStateOf(1.4f) }
    var physicsPhase by remember { mutableFloatStateOf(0f) }
    var physicsAngle by remember { mutableFloatStateOf(0f) }
    var physicsTime by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(playing) {
        if (playing) {
            while (playing && currentFrame < 600) {
                delay(1000L / 30L)
                currentFrame = (currentFrame + 1).coerceAtMost(600)
                if (selectedId != null && keyframes.isNotEmpty()) {
                    val ordered = keyframes.toSortedMap()
                    val before = ordered.entries.lastOrNull { it.key <= currentFrame }
                    val after = ordered.entries.firstOrNull { it.key >= currentFrame }
                    val a = before ?: after
                    val b = after ?: before
                    if (a != null && b != null) {
                        val span = (b.key - a.key).coerceAtLeast(1)
                        val t = if (a.key == b.key) 0f else ((currentFrame - a.key).toFloat() / span).coerceIn(0f, 1f)
                        fun mix(x: Float, y: Float) = x + (y - x) * t
                        val key = TransformKey(
                            mix(a.value.x, b.value.x),
                            mix(a.value.y, b.value.y),
                            mix(a.value.scale, b.value.scale),
                            mix(a.value.rotation, b.value.rotation),
                            mix(a.value.opacity, b.value.opacity)
                        )
                        layers = layers.map { layer -> if (layer.id == selectedId) layer.copy(x = key.x, y = key.y, scale = key.scale, rotation = key.rotation, opacity = key.opacity) else layer }
                    }
                }
                if (currentFrame >= 600) playing = false
            }
        }
    }
    LaunchedEffect(physicsEnabled, physicsSpeed, physicsAmplitude, physicsPhase) {
        if (physicsEnabled) {
            val start = System.nanoTime()
            while (true) {
                val seconds = (System.nanoTime() - start) / 1_000_000_000f
                physicsTime = seconds
                physicsAngle = sin(seconds * physicsSpeed * 2f * Math.PI.toFloat() + physicsPhase) * physicsAmplitude
                delay(16)
            }
        } else {
            physicsAngle = 0f
        }
    }
    val context = LocalContext.current
    val selected = layers.firstOrNull { it.id == selectedId }
    fun updateSelected(change: (ArtLayer) -> ArtLayer) {
        layers = layers.map { if (it.id == selectedId) change(it) else it }
    }
    fun recordKeyframe() {
        val layer = layers.firstOrNull { it.id == selectedId } ?: return
        keyframes = keyframes + (currentFrame to TransformKey(layer.x, layer.y, layer.scale, layer.rotation, layer.opacity))
    }
    fun applyNearestKeyframe(frame: Int) {
        val layer = layers.firstOrNull { it.id == selectedId } ?: return
        val key = keyframes[frame] ?: keyframes.filterKeys { it <= frame }.maxByOrNull { it.key }?.value
            ?: keyframes.filterKeys { it > frame }.minByOrNull { it.key }?.value ?: return
        updateSelected { it.copy(x = key.x, y = key.y, scale = key.scale, rotation = key.rotation, opacity = key.opacity) }
    }
    val saveProject = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null) {
            try {
                val temp = File(context.cacheDir, "galaxy-project.zip")
                writeGalaxyProject(temp, layers, eyeOpen, mouth, currentFrame, keyframes)
                context.contentResolver.openOutputStream(uri)?.use { output -> temp.inputStream().use { it.copyTo(output) } }
                android.widget.Toast.makeText(context, "프로젝트를 저장했어요.", android.widget.Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                android.widget.Toast.makeText(context, "저장 실패: ${e.localizedMessage}", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }
    val openProject = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                val loaded = context.contentResolver.openInputStream(uri)?.use { readGalaxyProject(it) }
                if (loaded != null) {
                    layers = loaded.layers
                    selectedId = layers.lastOrNull()?.id
                    eyeOpen = loaded.eyeOpen
                    mouth = loaded.mouth
                    currentFrame = loaded.frame
                    keyframes = loaded.keyframes
                    android.widget.Toast.makeText(context, "프로젝트를 불러왔어요.", android.widget.Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                android.widget.Toast.makeText(context, "불러오기 실패: ${e.localizedMessage}", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }
    val oraPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                val imported = context.contentResolver.openInputStream(uri)?.use { readOpenRaster(it) }.orEmpty()
                if (imported.isNotEmpty()) {
                    layers = layers + imported
                    selectedId = imported.last().id
                    android.widget.Toast.makeText(context, "OpenRaster 레이어 ${imported.size}개를 가져왔어요.", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    android.widget.Toast.makeText(context, "가져올 수 있는 레이어가 없습니다.", android.widget.Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                android.widget.Toast.makeText(context, "레이어 파일 읽기 실패: ${e.localizedMessage}", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        val added = uris.mapNotNull { uri ->
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)?.let { bitmap ->
                        ArtLayer(System.nanoTime() + bitmap.hashCode(), uri.lastPathSegment?.substringAfterLast('/')?.take(24) ?: "이미지 레이어", bitmap.asImageBitmap())
                    }
                }
            } catch (_: Exception) { null }
        }
        if (added.isNotEmpty()) { layers = layers + added; selectedId = added.last().id }
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(5.dp)) {
        Row(Modifier.fillMaxWidth().height(52.dp).background(Panel, RoundedCornerShape(9.dp)).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("◈ Live2D Studio", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("  GALAXY", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(18.dp))
            listOf("파일", "편집", "보기", "모델링", "애니메이션", "디포머", "물리", "설정").forEach {
                Text(it, color = if (selectedTop == it) Accent else Color(0xFFD7DCE6), fontSize = 12.sp,
                    modifier = Modifier.clickable { selectedTop = it }.padding(horizontal = 6.dp, vertical = 12.dp))
            }
            Spacer(Modifier.weight(1f))
            Text("열기", color = Color.White, fontSize = 11.sp, modifier = Modifier.clickable { openProject.launch(arrayOf("application/zip", "application/octet-stream")) }.padding(horizontal = 8.dp, vertical = 10.dp))
            Text("저장", color = Color.White, fontSize = 11.sp, modifier = Modifier.clickable { saveProject.launch("Live2DStudioGalaxy.galaxy.zip") }.padding(horizontal = 8.dp, vertical = 10.dp))
            Text("이미지 가져오기", color = Color.White, fontSize = 11.sp, modifier = Modifier.background(Accent, RoundedCornerShape(7.dp)).clickable { picker.launch(arrayOf("image/*")) }.padding(horizontal = 10.dp, vertical = 10.dp))
            Text("레이어 파일(.ora)", color = Color.White, fontSize = 11.sp, modifier = Modifier.background(Panel2, RoundedCornerShape(7.dp)).clickable { oraPicker.launch(arrayOf("image/openraster", "application/zip", "application/octet-stream")) }.padding(horizontal = 10.dp, vertical = 10.dp))
            Spacer(Modifier.width(8.dp))
            Text("${layers.size} Layers", color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(5.dp))
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Column(Modifier.fillMaxHeight().weight(0.23f).background(Panel, RoundedCornerShape(9.dp)).padding(9.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("파트 계층 · 순서 편집", color = Color.White, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); IconButton(onClick = { picker.launch(arrayOf("image/*")) }) { Icon(Icons.Default.Add, null, tint = Accent) } }
                HorizontalDivider(color = Panel2)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    item { Text("▾  캐릭터 프로젝트", color = Color(0xFFE4B66D), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)) }
                    items(layers, key = { it.id }) { layer ->
                        Row(Modifier.fillMaxWidth().background(if (selectedId == layer.id) Color(0xFF314C79) else Color.Transparent, RoundedCornerShape(5.dp)).clickable { selectedId = layer.id }.padding(horizontal = 5.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Layers, null, tint = Color(0xFF75A9FF), modifier = Modifier.size(15.dp))
                            Text(layer.name, color = Color(0xFFE3E7EF), fontSize = 11.sp, modifier = Modifier.weight(1f).padding(start = 6.dp), maxLines = 1)
                            IconButton(onClick = { layers = layers.map { if (it.id == layer.id) it.copy(visible = !it.visible) else it } }, modifier = Modifier.size(28.dp)) { Icon(if (layer.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff, null, tint = Muted, modifier = Modifier.size(16.dp)) }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("레이어 ${layers.size}개", color = Muted, fontSize = 10.sp)
            }
            Column(Modifier.fillMaxHeight().weight(0.52f).background(Panel, RoundedCornerShape(9.dp)).padding(7.dp)) {
                Row(Modifier.fillMaxWidth().height(30.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("NewModel  •  편집 캔버스", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f)); Text("−", color = Color.White, modifier = Modifier.clickable { zoom = (zoom - .1f).coerceIn(.3f, 3f) }.padding(horizontal = 8.dp)); Text("${(zoom * 100).toInt()}%", color = Muted, fontSize = 11.sp); Text("+", color = Color.White, modifier = Modifier.clickable { zoom = (zoom + .1f).coerceIn(.3f, 3f) }.padding(horizontal = 8.dp))
                }
                Box(Modifier.fillMaxSize().background(Color(0xFFB8BBC7), RoundedCornerShape(4.dp)).pointerInput(selectedId, zoom, layers) {
                    detectTransformGestures { centroid, pan, gestureZoom, rotation ->
                        if (selectedId != null) updateSelected { it.copy(x = it.x + pan.x, y = it.y + pan.y, scale = (it.scale * gestureZoom).coerceIn(.1f, 5f), rotation = it.rotation + rotation) }
                        else zoom = (zoom * gestureZoom).coerceIn(.3f, 3f)
                    }
                }) {
                    Canvas(Modifier.fillMaxSize()) {
                        val step = 28.dp.toPx()
                        for (x in 0..(size.width / step).toInt()) drawLine(Color(0x22818A9B), Offset(x * step, 0f), Offset(x * step, size.height), .6.dp.toPx())
                        for (y in 0..(size.height / step).toInt()) drawLine(Color(0x22818A9B), Offset(0f, y * step), Offset(size.width, y * step), .6.dp.toPx())
                        layers.filter { it.visible }.forEach { layer ->
                            val ratio = layer.bitmap.width.toFloat() / layer.bitmap.height.toFloat()
                            val maxW = size.width * .65f; val maxH = size.height * .72f
                            var w = maxW; var h = w / ratio
                            if (h > maxH) { h = maxH; w = h * ratio }
                            w *= layer.scale * zoom; h *= layer.scale * zoom
                            val center = Offset(size.width / 2 + layer.x, size.height / 2 + layer.y)
                            val linkedAngle = if (layer.id == selectedId && rigEnabled) rigAmount else 0f
                            val simulatedAngle = if (layer.id == selectedId && physicsEnabled) physicsAngle else 0f
                            drawContext.transform.rotate(layer.rotation + linkedAngle + simulatedAngle, center)
                            val tl = Offset(center.x - w / 2, center.y - h / 2)
                            drawImage(layer.bitmap, dstOffset = IntOffset(tl.x.toInt(), tl.y.toInt()), dstSize = IntSize(w.toInt().coerceAtLeast(1), h.toInt().coerceAtLeast(1)), alpha = layer.opacity)
                            if (layer.id == selectedId) drawRect(Accent, tl, Size(w, h), style = Stroke(2.dp.toPx()))
                            drawContext.transform.rotate(-(layer.rotation + linkedAngle + simulatedAngle), center)
                        }
                    }
                    Text(if (layers.isEmpty()) "이미지를 가져와 편집을 시작하세요" else "선택 레이어를 한 손가락으로 이동 · 두 손가락으로 크기/회전", color = Color(0xFF353B49), fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(7.dp))
                }
            }
            Column(Modifier.fillMaxHeight().weight(0.25f).background(Panel, RoundedCornerShape(9.dp)).padding(10.dp)) {
                Text("인스펙터", color = Color.White, fontWeight = FontWeight.Bold)
                Text(selected?.name ?: "선택된 레이어 없음", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
                HorizontalDivider(color = Panel2)
                if (selected != null) {
                    Text("변형", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 8.dp))
                    ValueSlider("크기", selected.scale, .1f..5f) { v -> updateSelected { it.copy(scale = v) } }
                    ValueSlider("회전", selected.rotation, -180f..180f) { v -> updateSelected { it.copy(rotation = v) } }
                    ValueSlider("불투명도", selected.opacity, 0f..1f) { v -> updateSelected { it.copy(opacity = v) } }
                    HorizontalDivider(color = Panel2, modifier = Modifier.padding(vertical = 7.dp))
                    HorizontalDivider(color = Panel2, modifier = Modifier.padding(vertical = 7.dp))
                    Text("물리 효과 · 흔들림 미리보기", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("실시간 물리 사용", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                        Switch(checked = physicsEnabled, onCheckedChange = { physicsEnabled = it })
                    }
                    ValueSlider("흔들림 진폭", physicsAmplitude, 0f..35f) { physicsAmplitude = it }
                    ValueSlider("진동 속도", physicsSpeed, .1f..4f) { physicsSpeed = it }
                    ValueSlider("위상", physicsPhase, -3.14f..3.14f) { physicsPhase = it }
                    Text("현재 각도 ${"%.1f".format(physicsAngle)}°", color = Muted, fontSize = 9.sp)
                    HorizontalDivider(color = Panel2, modifier = Modifier.padding(vertical = 7.dp))
                    Text("파라미터 리깅 · 회전 연결", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("연결 사용", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                        Switch(checked = rigEnabled, onCheckedChange = { rigEnabled = it })
                    }
                    ValueSlider("회전 반응", rigAmount, -30f..30f) { rigAmount = it }
                    Text("선택 레이어에 파라미터 회전값을 적용합니다.", color = Muted, fontSize = 9.sp)
                    Text("위치  X ${selected.x.toInt()}  Y ${selected.y.toInt()}", color = Muted, fontSize = 10.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(top = 8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val index = layers.indexOfFirst { it.id == selectedId }
                                if (index > 0) layers = layers.toMutableList().also { list ->
                                    val item = list.removeAt(index)
                                    list.add(index - 1, item)
                                }
                            },
                            enabled = layers.indexOfFirst { it.id == selectedId } > 0,
                            contentPadding = PaddingValues(horizontal = 7.dp)
                        ) { Text("위로", fontSize = 10.sp) }
                        OutlinedButton(
                            onClick = {
                                val index = layers.indexOfFirst { it.id == selectedId }
                                if (index >= 0 && index < layers.lastIndex) layers = layers.toMutableList().also { list ->
                                    val item = list.removeAt(index)
                                    list.add(index + 1, item)
                                }
                            },
                            enabled = layers.indexOfFirst { it.id == selectedId } in 0 until layers.lastIndex,
                            contentPadding = PaddingValues(horizontal = 7.dp)
                        ) { Text("아래로", fontSize = 10.sp) }
                        OutlinedButton(onClick = { updateSelected { it.copy(x = 0f, y = 0f, scale = 1f, rotation = 0f, opacity = 1f) } }, contentPadding = PaddingValues(horizontal = 7.dp)) { Text("초기화", fontSize = 10.sp) }
                        OutlinedButton(onClick = { layers = layers.filterNot { it.id == selectedId }; selectedId = layers.lastOrNull()?.id }, contentPadding = PaddingValues(horizontal = 7.dp)) { Text("삭제", fontSize = 10.sp) }
                    }
                } else Text("왼쪽에서 레이어를 선택하거나 이미지를 가져오세요.", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text("물리 미리보기는 선택 레이어에 적용됩니다.", color = Muted, fontSize = 9.sp)
            }
        }
        Spacer(Modifier.height(5.dp))
        Row(Modifier.fillMaxWidth().height(155.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Column(Modifier.weight(.30f).fillMaxHeight().background(Panel, RoundedCornerShape(9.dp)).padding(9.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) { listOf("파라미터", "키프레임").forEach { Text(it, color = if (bottomTab == it) Color.White else Muted, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { bottomTab = it }.padding(vertical = 4.dp)) } }
                HorizontalDivider(color = Panel2)
                if (bottomTab == "파라미터") { ParamSlider("눈 열림", eyeOpen) { eyeOpen = it }; ParamSlider("입 모양", mouth) { mouth = it } }
                else Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("선택 레이어의 변형 키프레임", color = Muted, fontSize = 10.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Button(onClick = { recordKeyframe() }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) { Text("현재 프레임 키 추가", fontSize = 9.sp) }
                        OutlinedButton(onClick = { keyframes = keyframes - currentFrame }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) { Text("현재 키 삭제", fontSize = 9.sp) }
                    }
                    Text("키 ${keyframes.size}개 · 선택 프레임 ${currentFrame}f", color = Muted, fontSize = 9.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        keyframes.keys.sorted().take(8).forEach { frame ->
                            Text("◆ $frame", color = if (frame == currentFrame) Accent else Color(0xFFE5C16B), fontSize = 9.sp,
                                modifier = Modifier.clickable { currentFrame = frame; applyNearestKeyframe(frame) }.background(Panel2, RoundedCornerShape(4.dp)).padding(4.dp))
                        }
                    }
                }
            }
            Column(Modifier.weight(.70f).fillMaxHeight().background(Panel, RoundedCornerShape(9.dp)).padding(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("모션 타임라인", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { currentFrame = max(0, currentFrame - 1) }) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                    IconButton(onClick = { playing = !playing }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Accent) }
                    IconButton(onClick = { currentFrame = min(600, currentFrame + 1) }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                    Text("$currentFrame / 600f", color = Muted, fontSize = 11.sp)
                }
                Slider(value = currentFrame.toFloat(), onValueChange = { currentFrame = it.toInt(); applyNearestKeyframe(it.toInt()) }, valueRange = 0f..600f)
                Text("키프레임 보간 미리보기 · 프로젝트 저장/불러오기 지원 (Cubism Motion3 내보내기는 미지원)", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun ValueSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit) {
    Column(Modifier.padding(top = 5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(label, color = Color(0xFFE0E5EF), fontSize = 11.sp); Spacer(Modifier.weight(1f)); Text(if (label == "불투명도") "${(value * 100).toInt()}%" else String.format("%.1f", value), color = Muted, fontSize = 10.sp) }
        Slider(value = value.coerceIn(range), onValueChange = onValue, valueRange = range, modifier = Modifier.height(29.dp), colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
    }
}

@Composable
private fun ParamSlider(label: String, value: Float, onValue: (Float) -> Unit) {
    Column(Modifier.padding(top = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(label, color = Color(0xFFE0E5EF), fontSize = 11.sp); Spacer(Modifier.weight(1f)); Text("${(value * 100).toInt()}", color = Muted, fontSize = 10.sp) }
        Slider(value = value, onValueChange = onValue, modifier = Modifier.height(27.dp), colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
    }
}


/** OpenRaster(.ora) is a ZIP-based layered image interchange format. */
private fun readOpenRaster(input: java.io.InputStream): List<ArtLayer> {
    val entries = mutableMapOf<String, ByteArray>()
    ZipInputStream(input.buffered()).use { zip ->
        while (true) {
            val entry = zip.nextEntry ?: break
            if (!entry.isDirectory && !entry.name.startsWith("/") && !entry.name.split('/').contains("..")) {
                entries[entry.name] = zip.readBytes()
            }
            zip.closeEntry()
        }
    }
    val stack = entries["stack.xml"] ?: error("OpenRaster 파일에 stack.xml이 없습니다.")
    val parser = Xml.newPullParser()
    parser.setInput(stack.inputStream(), "UTF-8")
    val result = mutableListOf<ArtLayer>()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        if (event == XmlPullParser.START_TAG && parser.name == "layer") {
            val src = parser.getAttributeValue(null, "src") ?: ""
            val safePath = src.replace('\\', '/')
            require(!safePath.startsWith("/") && !safePath.split('/').contains("..")) { "잘못된 레이어 경로입니다." }
            val bytes = entries[safePath]
            if (bytes != null) {
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bitmap != null) {
                    val layerName = parser.getAttributeValue(null, "name") ?: "ORA 레이어 ${result.size + 1}"
                    val x = parser.getAttributeValue(null, "x")?.toFloatOrNull() ?: 0f
                    val y = parser.getAttributeValue(null, "y")?.toFloatOrNull() ?: 0f
                    val opacity = (parser.getAttributeValue(null, "opacity")?.toFloatOrNull() ?: 1f).coerceIn(0f, 1f)
                    val visible = parser.getAttributeValue(null, "visibility") != "hidden"
                    result.add(ArtLayer(System.nanoTime() + result.size, layerName, bitmap.asImageBitmap(), x, y, 1f, 0f, opacity, visible))
                }
            }
        }
        event = parser.next()
    }
    // OpenRaster stores layers from top to bottom; reverse so the visual stacking order is preserved in our canvas list.
    return result.reversed()
}

private data class LoadedGalaxyProject(val layers: List<ArtLayer>, val eyeOpen: Float, val mouth: Float, val frame: Int, val keyframes: Map<Int, TransformKey>)

private fun writeGalaxyProject(file: File, layers: List<ArtLayer>, eyeOpen: Float, mouth: Float, frame: Int, keyframes: Map<Int, TransformKey>) {
    val manifest = JSONObject()
    manifest.put("format", "Live2DStudioGalaxy")
    manifest.put("version", 2)
    manifest.put("eyeOpen", eyeOpen.toDouble())
    manifest.put("mouth", mouth.toDouble())
    manifest.put("frame", frame)
    val items = JSONArray()
    layers.forEachIndexed { index, layer ->
        val imageName = "images/layer_$index.png"
        val item = JSONObject()
        item.put("id", layer.id)
        item.put("name", layer.name)
        item.put("image", imageName)
        item.put("x", layer.x.toDouble())
        item.put("y", layer.y.toDouble())
        item.put("scale", layer.scale.toDouble())
        item.put("rotation", layer.rotation.toDouble())
        item.put("opacity", layer.opacity.toDouble())
        item.put("visible", layer.visible)
        items.put(item)
    }
    manifest.put("layers", items)
    val keyItems = JSONArray()
    keyframes.toSortedMap().forEach { (frameNo, key) ->
        val item = JSONObject()
        item.put("frame", frameNo)
        item.put("x", key.x.toDouble())
        item.put("y", key.y.toDouble())
        item.put("scale", key.scale.toDouble())
        item.put("rotation", key.rotation.toDouble())
        item.put("opacity", key.opacity.toDouble())
        keyItems.put(item)
    }
    manifest.put("keyframes", keyItems)
    ZipOutputStream(file.outputStream().buffered()).use { zip ->
        zip.putNextEntry(ZipEntry("project.json"))
        zip.write(manifest.toString(2).toByteArray(Charsets.UTF_8))
        zip.closeEntry()
        layers.forEachIndexed { index, layer ->
            zip.putNextEntry(ZipEntry("images/layer_$index.png"))
            layer.bitmap.asAndroidBitmap().compress(Bitmap.CompressFormat.PNG, 100, zip)
            zip.closeEntry()
        }
    }
}

private fun readGalaxyProject(input: java.io.InputStream): LoadedGalaxyProject {
    val entries = mutableMapOf<String, ByteArray>()
    ZipInputStream(input.buffered()).use { zip ->
        while (true) {
            val entry = zip.nextEntry ?: break
            if (!entry.isDirectory && !entry.name.startsWith("/") && !entry.name.contains("..")) {
                entries[entry.name] = zip.readBytes()
            }
            zip.closeEntry()
        }
    }
    val manifestBytes = entries["project.json"] ?: error("프로젝트 정보(project.json)가 없습니다.")
    val manifest = JSONObject(String(manifestBytes, Charsets.UTF_8))
    require(manifest.optString("format") == "Live2DStudioGalaxy") { "지원하지 않는 프로젝트 파일입니다." }
    val array = manifest.optJSONArray("layers") ?: JSONArray()
    val layers = (0 until array.length()).mapNotNull { index ->
        val item = array.getJSONObject(index)
        val bytes = entries[item.getString("image")] ?: return@mapNotNull null
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@mapNotNull null
        ArtLayer(
            id = item.optLong("id", System.nanoTime() + index),
            name = item.optString("name", "이미지 레이어"),
            bitmap = bitmap.asImageBitmap(),
            x = item.optDouble("x", 0.0).toFloat(),
            y = item.optDouble("y", 0.0).toFloat(),
            scale = item.optDouble("scale", 1.0).toFloat(),
            rotation = item.optDouble("rotation", 0.0).toFloat(),
            opacity = item.optDouble("opacity", 1.0).toFloat(),
            visible = item.optBoolean("visible", true)
        )
    }
    val keyArray = manifest.optJSONArray("keyframes") ?: JSONArray()
    val keys = (0 until keyArray.length()).associate { index ->
        val item = keyArray.getJSONObject(index)
        item.optInt("frame", 0) to TransformKey(
            item.optDouble("x", 0.0).toFloat(),
            item.optDouble("y", 0.0).toFloat(),
            item.optDouble("scale", 1.0).toFloat(),
            item.optDouble("rotation", 0.0).toFloat(),
            item.optDouble("opacity", 1.0).toFloat()
        )
    }
    return LoadedGalaxyProject(layers, manifest.optDouble("eyeOpen", .65).toFloat(), manifest.optDouble("mouth", .25).toFloat(), manifest.optInt("frame", 0), keys)
}
